package net.dragonmounts.neo.common.init;

import net.dragonmounts.neo.common.tag.DMItemTags;
import net.dragonmounts.neo.common.type.*;
import net.dragonmounts.neo.common.util.ArmorMaterialBuilder;
import net.dragonmounts.neo.common.util.ItemTierBuilder;
import net.dragonmounts.neo.compat.registry.DragonType;
import net.dragonmounts.neo.compat.registry.DragonTypeBuilder;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.material.MapColor;

import static net.dragonmounts.neo.common.DragonMountsShared.makeId;
import static net.dragonmounts.neo.compat.registry.DragonTypeBuilder.BONUS_ID;
import static net.minecraft.world.item.ArmorItem.Type.*;

public class DragonTypes {
    public static final DragonType AETHER;
    public static final DragonType DARK;
    public static final DragonType LIGHT;
    public static final DragonType ENCHANTED;
    public static final DragonType ENDER;
    public static final DragonType FIRE;
    public static final DragonType FOREST;
    public static final DragonType ICE;
    public static final DragonType MOONLIGHT;
    public static final DragonType NETHER;
    public static final DragonType SCULK;
    public static final DragonType SKELETON;
    public static final DragonType STORM;
    public static final DragonType SUNLIGHT;
    public static final DragonType TERRA;
    public static final DragonType WATER;
    public static final DragonType WITHER;
    public static final DragonType ZOMBIE;

    static {
        var netherite = BlockTags.INCORRECT_FOR_NETHERITE_TOOL;
        var material = new ArmorMaterialBuilder(50)
                .setDefense(HELMET, 3)
                .setDefense(CHESTPLATE, 8)
                .setDefense(LEGGINGS, 7)
                .setDefense(BOOTS, 3)
                .setEnchantmentValue(11)
                .setToughness(7.0F);
        var tier = new ItemTierBuilder(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 2700, 8.0F, 5.0F)
                .setEnchantmentValue(11);
        MOONLIGHT = new DragonTypeBuilder(0x2C427C, material, tier)
                .model("normal", "base")
                .texture(makeId("textures/entity/dragon/moonlight/constellation/body.png"))
                .setMaterial(DMItemTags.MOONLIGHT_DRAGON_SCALES)
                .setScaleColor(MapColor.COLOR_BLUE)
                .addHabitat(Blocks.BLUE_GLAZED_TERRACOTTA)
                .register(MoonlightType::new, makeId("moonlight"));
        TERRA = new DragonTypeBuilder(0xA56C21, material, tier)
                .model("bland", "base")   // TODO confirm body shape (old COMPAT)
                .texture(makeId("textures/entity/dragon/terra/female/body.png"))
                .setMaterial(DMItemTags.TERRA_DRAGON_SCALES)
                .setScaleColor(MapColor.DIRT)
                .addHabitat(Blocks.TERRACOTTA)
                .addHabitat(Blocks.SAND)
                .addHabitat(Blocks.SANDSTONE)
                .addHabitat(Blocks.SANDSTONE_SLAB)
                .addHabitat(Blocks.SANDSTONE_STAIRS)
                .addHabitat(Blocks.SANDSTONE_WALL)
                .addHabitat(Blocks.RED_SAND)
                .addHabitat(Blocks.RED_SANDSTONE)
                .addHabitat(Blocks.RED_SANDSTONE_SLAB)
                .addHabitat(Blocks.RED_SANDSTONE_STAIRS)
                .addHabitat(Blocks.RED_SANDSTONE_WALL)
                //.addHabitat(BiomeKeys.MESA)
                //.addHabitat(BiomeKeys.MESA_ROCK)
                //.addHabitat(BiomeKeys.MESA_CLEAR_ROCK)
                //.addHabitat(BiomeKeys.MUTATED_MESA_CLEAR_ROCK)
                //.addHabitat(BiomeKeys.MUTATED_MESA_ROCK)
                .register(TerraType::new, makeId("terra"));
        ZOMBIE = new DragonTypeBuilder(0x5A5602, material, tier)
                .model("skeleton", "skeleton")
                .texture(makeId("textures/entity/dragon/zombie/body.png"))
                .setMaterial(DMItemTags.ZOMBIE_DRAGON_SCALES)
                .setScaleColor(MapColor.TERRACOTTA_GREEN)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .addHabitat(Blocks.SOUL_SAND)
                .addHabitat(Blocks.SOUL_SAND)
                .addHabitat(Blocks.NETHER_WART_BLOCK)
                .addHabitat(Blocks.WARPED_WART_BLOCK)
                .register(ZombieType::new, makeId("zombie"));
        DARK = new DragonTypeBuilder(0x808080, material.setDefense(HELMET, 5), tier)
                .model("normal", "base")
                .texture(makeId("textures/entity/dragon/dark/bloodmoon/body.png"))
                .setMaterial(DMItemTags.DARK_DRAGON_SCALES)
                .setScaleColor(MapColor.DEEPSLATE)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .register(DarkType::new, makeId("dark"));
        LIGHT = new DragonTypeBuilder(0x808080, material.setDefense(HELMET, 5), tier)
                .model("winged_horned", "winged_horned")
                .texture(makeId("textures/entity/dragon/light/prism/body.png"))
                .setMaterial(DMItemTags.LIGHT_DRAGON_SCALES)
                .setScaleColor(MapColor.COLOR_YELLOW)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .register(LightType::new, makeId("light"));
        material.setDefense(HELMET, 4).setDefense(BOOTS, 4);
        AETHER = new DragonTypeBuilder(0x0294BD, material, new ItemTierBuilder(netherite, 2700, 8.0F, 5.0F).setEnchantmentValue(11))
                .model("normal", "base")   // TODO confirm body shape (old COMPAT)
                .texture(makeId("textures/entity/dragon/aether/aether/body.png"))
                .setMaterial(DMItemTags.AETHER_DRAGON_SCALES)
                .setScaleColor(MapColor.COLOR_LIGHT_BLUE)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .addHabitat(Blocks.LAPIS_BLOCK)
                //.addHabitat(Blocks.LIT_FURNACE)
                //.addHabitat(Blocks.FLOWING_LAVA)
                .addHabitat(Blocks.LAPIS_ORE)
                .register(AetherType::new, makeId("aether"));
        FIRE = new DragonTypeBuilder(0x960B0F, material, tier)
                .model("normal", "base")
                .texture(makeId("textures/entity/dragon/fire/fire/body.png"))
                .setMaterial(DMItemTags.FIRE_DRAGON_SCALES)
                .setScaleColor(MapColor.FIRE)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .addHabitat(Blocks.FIRE)
                //.addHabitat(Blocks.LIT_FURNACE)
                //.addHabitat(Blocks.YELLOW_FLOWER)
                //.addHabitat(Blocks.RED_FLOWER)
                //.addHabitat(Blocks.SAPLING)
                //.addHabitat(Blocks.LEAVES)
                //.addHabitat(Blocks.LEAVES2)
                //.addHabitat(Biomes.JUNGLE_HILLS)
                .addHabitat(Blocks.LAVA)
                .register(FireType::new, makeId("fire"));
        FOREST = new DragonTypeBuilder(0x298317, material, tier)
                .model("horned_antlers", "horned_antlers")
                .texture(makeId("textures/entity/dragon/forest/nature/body.png"))
                .setMaterial(DMItemTags.FOREST_DRAGON_SCALES)
                .setScaleColor(MapColor.COLOR_GREEN)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .addEffectImmunity(MobEffects.POISON)
                .setSneezeParticle(ParticleTypes.HAPPY_VILLAGER)
                //.addHabitat(Blocks.YELLOW_FLOWER)
                //.addHabitat(Blocks.RED_FLOWER)
                .addHabitat(Blocks.MOSSY_COBBLESTONE)
                .addHabitat(Blocks.VINE)
                //.addHabitat(Blocks.SAPLING)
                //.addHabitat(Blocks.LEAVES)
                //.addHabitat(Blocks.LEAVES2)
                //.addHabitat(BiomeKeys.JUNGLE)
                //.addHabitat(BiomeKeys.JUNGLE_HILLS)
                .addHabitat(Biomes.JUNGLE)
                .register(ForestType::new, makeId("forest"));
        ICE = new DragonTypeBuilder(0x00F2FF, material, tier)
                .model("tail_scale_inclined", "base")
                .texture(makeId("textures/entity/dragon/ice/frost/body.png"))
                .setMaterial(DMItemTags.ICE_DRAGON_SCALES)
                .setScaleColor(MapColor.SNOW)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .setSneezeParticle(ParticleTypes.SNOWFLAKE)
                .addHabitat(Blocks.SNOW)
                .addHabitat(Blocks.ICE)
                .addHabitat(Blocks.PACKED_ICE)
                .addHabitat(Blocks.FROSTED_ICE)
                .addHabitat(Biomes.FROZEN_OCEAN)
                .addHabitat(Biomes.FROZEN_RIVER)
                .register(IceType::new, makeId("ice"));
        STORM = new DragonTypeBuilder(0xF5F1E9, material, tier)
                .model("tail_horned", "base")
                .texture(makeId("textures/entity/dragon/storm/thunder/body.png"))
                .setMaterial(DMItemTags.STORM_DRAGON_SCALES)
                .setScaleColor(MapColor.WOOL)
                .register(StormType::new, makeId("storm"));
        SUNLIGHT = new DragonTypeBuilder(0xFFDE00, material, tier)
                .model("normal", "base")
                .texture(makeId("textures/entity/dragon/sunlight/aurora/body.png"))
                .setMaterial(DMItemTags.SUNLIGHT_DRAGON_SCALES)
                .setScaleColor(MapColor.COLOR_YELLOW)
                .addHabitat(Blocks.GLOWSTONE)
                .addHabitat(Blocks.JACK_O_LANTERN)
                .addHabitat(Blocks.SHROOMLIGHT)
                .addHabitat(Blocks.YELLOW_GLAZED_TERRACOTTA)
                .register(SunlightType::new, makeId("sunlight"));
        WATER = new DragonTypeBuilder(0x4F69A8, material, tier)
                .model("scale_sharpened", "base")
                .texture(makeId("textures/entity/dragon/water/pond/body.png"))
                .setMaterial(DMItemTags.WATER_DRAGON_SCALES)
                .setScaleColor(MapColor.WATER)
                .addImmunity(DamageTypes.DROWN)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .addHabitat(Blocks.WATER)
                .addHabitat(Biomes.OCEAN)
                .addHabitat(Biomes.RIVER)
                .register(WaterType::new, makeId("water"));
        //modify builder
        ENCHANTED = new DragonTypeBuilder(0x8359AE, material.setEnchantmentValue(30), tier.setEnchantmentValue(30))
                .model("normal", "base")
                .texture(makeId("textures/entity/dragon/enchanted/enchanting/body.png"))
                .setMaterial(DMItemTags.ENCHANTED_DRAGON_SCALES)
                .setScaleColor(MapColor.COLOR_PURPLE)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .addHabitat(Blocks.BOOKSHELF)
                .addHabitat(Blocks.ENCHANTING_TABLE)
                .register(EnchantedType::new, makeId("enchanted"));
        material.setDurabilityFactor(70)
                .setDefense(CHESTPLATE, 9)
                .setEnchantmentValue(11)
                .setToughness(9.0F);
        tier = new ItemTierBuilder(netherite, 3000, 8.0F, 6.0F).setEnchantmentValue(11);
        ENDER = new DragonTypeBuilder(0xAB39BE, material, tier)
                .model("normal", "base")   // TODO confirm body shape (old COMPAT)
                .texture(makeId("textures/entity/dragon/ender/female/body.png"))
                .setMaterial(DMItemTags.ENDER_DRAGON_SCALES)
                .setScaleColor(MapColor.COLOR_BLACK)
                .notConvertible()
                .putAttributeModifier(Attributes.MAX_HEALTH, BONUS_ID, 10.0D, AttributeModifier.Operation.ADD_VALUE)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .setSneezeParticle(ParticleTypes.PORTAL)
                .setEggParticle(ParticleTypes.PORTAL)
                .register(EnderType::new, DragonType.DEFAULT_KEY);
        SCULK = new DragonTypeBuilder(0x29DFEB, material, tier)
                .model("sculk", "base")
                .texture(makeId("textures/entity/dragon/sculk/wild_type/body.png"))
                .setMaterial(DMItemTags.SCULK_DRAGON_SCALES)
                .setScaleColor(MapColor.COLOR_BLACK)
                .notConvertible()
                .putAttributeModifier(Attributes.MAX_HEALTH, BONUS_ID, 10.0D, AttributeModifier.Operation.ADD_VALUE)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .register(SculkType::new, makeId("sculk"));
        //modify builders
        NETHER = new DragonTypeBuilder(0xE5B81B, material.setDurabilityFactor(55).setToughness(8.0F), new ItemTierBuilder(netherite, 2700, 8.0F, 6.0F).setEnchantmentValue(11))
                .model("scale_sharpened", "base")
                .texture(makeId("textures/entity/dragon/nether/magma/body.png"))
                .setMaterial(DMItemTags.NETHER_DRAGON_SCALES)
                .setScaleColor(MapColor.NETHER)
                .putAttributeModifier(Attributes.MAX_HEALTH, BONUS_ID, 5.0D, AttributeModifier.Operation.ADD_VALUE)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                //.addHabitat(BiomeKeys.HELL)
                .setEggParticle(ParticleTypes.DRIPPING_LAVA)
                .register(NetherType::new, makeId("nether"));
        //no scale items
        // Bone is lighter and less protective than scale: slightly lower defence and a
        // shorter-lived tier than the scale types, but it keeps a high enchantment value.
        var boneMaterial = new ArmorMaterialBuilder(50)
                .setDefense(HELMET, 2)
                .setDefense(CHESTPLATE, 7)
                .setDefense(LEGGINGS, 5)
                .setDefense(BOOTS, 2)
                .setEnchantmentValue(13)
                .setToughness(4.0F);
        var boneTier = new ItemTierBuilder(BlockTags.INCORRECT_FOR_DIAMOND_TOOL, 2100, 8.0F, 4.0F)
                .setEnchantmentValue(13);
        SKELETON = new DragonTypeBuilder(0xFFFFFF, boneMaterial, boneTier)
                .setMaterial(DMItemTags.SKELETON_DRAGON_BONES)
                .model("skeleton", "skeleton")
                .texture(makeId("textures/entity/dragon/skeleton/normal/body.png"))
                .putAttributeModifier(Attributes.MAX_HEALTH, BONUS_ID, -15.0D, AttributeModifier.Operation.ADD_VALUE)
                .setScaleColor(MapColor.QUARTZ)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .addHabitat(Blocks.BONE_BLOCK)
                .register(SkeletonType::new, makeId("skeleton"));
        WITHER = new DragonTypeBuilder(0x50260A,
                new ArmorMaterialBuilder(50)
                        .setDefense(HELMET, 3)
                        .setDefense(CHESTPLATE, 8)
                        .setDefense(LEGGINGS, 6)
                        .setDefense(BOOTS, 3)
                        .setEnchantmentValue(13)
                        .setToughness(5.0F),
                new ItemTierBuilder(netherite, 2400, 8.0F, 5.0F).setEnchantmentValue(13))
                .setMaterial(DMItemTags.WITHER_DRAGON_BONES)
                .model("spiked_horned", "spiked_horned")   // TODO confirm body shape (old WITHER)
                .texture(makeId("textures/entity/dragon/wither/body.png"))
                .notConvertible()
                .putAttributeModifier(Attributes.MAX_HEALTH, BONUS_ID, -10.0D, AttributeModifier.Operation.ADD_VALUE)
                .setScaleColor(MapColor.COLOR_GRAY)
                .addImmunity(DamageTypes.MAGIC)
                .addImmunity(DamageTypes.HOT_FLOOR)
                .addImmunity(DamageTypes.LIGHTNING_BOLT)
                .addImmunity(DamageTypes.WITHER)
                .register(WitherType::new, makeId("wither"));
    }

    /// Loading this class is what performs the registration; the body is intentionally empty.
    /// Called explicitly from each loader's entrypoint so the order is declared rather than
    /// inherited from whichever other init class happens to touch it first.
    public static void init() {}
}
