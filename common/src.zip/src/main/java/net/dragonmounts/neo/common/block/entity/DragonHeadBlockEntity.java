package net.dragonmounts.neo.common.block.entity;

import net.dragonmounts.neo.common.init.DMBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import software.bernie.geckolib.animatable.GeoBlockEntity;
import software.bernie.geckolib.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.animation.AnimatableManager;
import software.bernie.geckolib.animation.AnimationController;
import software.bernie.geckolib.animation.RawAnimation;
import software.bernie.geckolib.util.GeckoLibUtil;

import static net.minecraft.world.level.block.state.properties.BlockStateProperties.POWERED;

/// @see net.minecraft.world.level.block.entity.SkullBlockEntity
public class DragonHeadBlockEntity extends BlockEntity implements GeoBlockEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public DragonHeadBlockEntity(BlockPos pos, BlockState state) {
        super(DMBlockEntities.DRAGON_HEAD.get(), pos, state);
    }

    private int ticks;
    private boolean active;

    public float getAnimation(float partialTicks) {
        return this.active ? partialTicks + (float) this.ticks : (float) this.ticks;
    }

    public static void animation(Level level, BlockPos pos, BlockState state, DragonHeadBlockEntity entity) {
        if (state.hasProperty(POWERED) && state.getValue(POWERED)) {
            entity.active = true;
            ++entity.ticks;
        } else {
            entity.active = false;
        }
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
//        controllers.add(new AnimationController<>(this, "jaw_controller", 3, state ->
//                state.setAndContinue(this.active
//                        ? RawAnimation.begin().thenPlay("animation.dragonmounts2.dragon.dragon_head.jaw_open")
//                        : RawAnimation.begin().thenPlay("animation.dragonmounts2.dragon.jaw_close"))
//        ));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }
}